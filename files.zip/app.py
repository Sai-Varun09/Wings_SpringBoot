from flask import Flask, jsonify, render_template
import random

app = Flask(__name__)

# ── DATA STORE ──────────────────────────────────────────────────────────────

OVERALL_CHECKOUTS = [
    {"name": "BAM Bundle"},
    {"name": "Membership Bundle"},
    {"name": "ECM Bundle"},
    {"name": "UCR Bundle"},
    {"name": "OTX Bundle"},
    {"name": "BMSP Bundle"},
    {"name": "EMA Bundle"},
    {"name": "Empower Set"},
]

APP_CHECKOUTS = [
    {"app_id": "APP00000000", "name": "Coverage API"},
    {"app_id": "APP00000001", "name": "Claims API"},
    {"app_id": "APP00000002", "name": "Legal Privacy Content API"},
    {"app_id": "APP00000003", "name": "Member Restriction API"},
    {"app_id": "APP00000004", "name": "Membership API (Future State)"},
    {"app_id": "APP00000005", "name": "Member ID Card"},
    {"app_id": "APP00000006", "name": "Member Profile User Interface"},
    {"app_id": "APP00000007", "name": "BCBSor Native Mobile App"},
    {"app_id": "APP00000008", "name": "Demographics API"},
    {"app_id": "APP00000009", "name": "Contact Info API"},
]

DASHBOARDS = [
    {"name": "TCS Digital Dyna Dashboard"},
    {"name": "ARES EOB Dashboard"},
    {"name": "TCS ARES AYS Dashboard"},
    {"name": "ARES EOB Dashboard Refresh"},
]

MONITORING = [
    {"name": "OTX Critical Job Flow"},
    {"name": "UIB Stuck Record Monitoring"},
    {"name": "EOB Flow Monitoring"},
    {"name": "ECM Batch Flow"},
    {"name": "Captiva File Count"},
    {"name": "BMSP Rabbit MQ Monitoring"},
    {"name": "OTX/FSS Report"},
    {"name": "OTX/ORMB Flow"},
]

DIGITAL_REPORTING = [
    {"name": "Incident Inventory"},
    {"name": "Open Task"},
]


def random_status():
    return random.choice(["Pass", "Pass", "Pass", "Fail"])


# ── API ROUTES ───────────────────────────────────────────────────────────────

@app.route("/api/overall-checkouts")
def api_overall_checkouts():
    data = [{"name": item["name"], "status": random_status()} for item in OVERALL_CHECKOUTS]
    return jsonify(data)


@app.route("/api/app-checkouts")
def api_app_checkouts():
    data = [{"app_id": item["app_id"], "name": item["name"], "status": random_status()} for item in APP_CHECKOUTS]
    return jsonify(data)


@app.route("/api/app-checkouts-preview")
@login_required
def api_app_checkouts_preview():
    """
    Mirrors the /digital route logic exactly:
    - Queries CheckoutStatus for all rows (same DB + CHECKOUT_STRUCTURE as /digital)
    - Sorts by name  →  table.sort(key=lambda x: x['name'].lower())
    - Returns only the TOP 5 for the home page preview card
    - Each item carries the latest status (Adhoc preferred over Scheduled)
    """
    rows = CheckoutStatus.query.all()

    # Build lookup identical to /digital
    lookup = {}
    for r in rows:
        lookup[(r.checkout_name.strip(), r.run_type.strip())] = r

    table = []
    for checkout, runs in CHECKOUT_STRUCTURE.items():
        # Prefer Adhoc status; fall back to Scheduled
        adhoc_row     = lookup.get((checkout, "Adhoc"))
        scheduled_row = lookup.get((checkout, "Scheduled"))
        best_row      = adhoc_row or scheduled_row

        table.append({
            "name"    : checkout,
            "status"  : best_row.checkout_status if best_row else "",
            "run_type": best_row.run_type        if best_row else "",
            "date"    : str(best_row.checkout_date)  if best_row else "",
            "time"    : best_row.reported_time    if best_row else "",
        })

    # Exact same sort as /digital
    table.sort(key=lambda x: x["name"].lower())

    # Top 5 only
    top5 = table[:5]

    result = []
    for i, item in enumerate(top5):
        result.append({
            "app_id"  : f"APP{str(i).zfill(8)}",
            "name"    : item["name"],
            "status"  : item["status"] or None,
            "run_type": item["run_type"],
            "date"    : item["date"],
            "time"    : item["time"],
        })

    return jsonify(result)


@app.route("/api/dashboards")
def api_dashboards():
    data = []
    for item in DASHBOARDS:
        entry = {"name": item["name"]}
        # Last item has status, others just button
        if item["name"] == "ARES EOB Dashboard Refresh":
            entry["status"] = random_status()
        data.append(entry)
    return jsonify(data)


@app.route("/api/monitoring")
def api_monitoring():
    data = [{"name": item["name"], "status": random_status()} for item in MONITORING]
    return jsonify(data)


@app.route("/api/digital-reporting")
def api_digital_reporting():
    data = [{"name": item["name"], "status": random_status()} for item in DIGITAL_REPORTING]
    return jsonify(data)


@app.route("/api/all")
def api_all():
    return jsonify({
        "overall_checkouts": [{"name": i["name"], "status": random_status()} for i in OVERALL_CHECKOUTS],
        "app_checkouts": [{"app_id": i["app_id"], "name": i["name"], "status": random_status()} for i in APP_CHECKOUTS],
        "dashboards": [{"name": i["name"], "status": random_status() if i["name"] == "ARES EOB Dashboard Refresh" else None} for i in DASHBOARDS],
        "monitoring": [{"name": i["name"], "status": random_status()} for i in MONITORING],
        "digital_reporting": [{"name": i["name"], "status": random_status()} for i in DIGITAL_REPORTING],
    })


@app.route("/")
def index():
    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True, port=5000)
