package com.example.demoSecurity3.demoSecurity3.Repository;

import com.example.demoSecurity3.demoSecurity3.Model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {
}
