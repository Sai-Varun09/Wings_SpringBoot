package com.example.demoSecurity3.demoSecurity3.Controller;

import com.example.demoSecurity3.demoSecurity3.Model.Book;
import com.example.demoSecurity3.demoSecurity3.Service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/Admin")
public class AdminController {

    @Autowired
    AdminService adminService;

    @PostMapping("/addBook")
    public ResponseEntity<?> addBook(@RequestBody Book book){
        return adminService.addBook(book);
    }

    @GetMapping("/allBooks")
    public ResponseEntity<?> allBooks(){
        return adminService.allBooks();
    }
}
