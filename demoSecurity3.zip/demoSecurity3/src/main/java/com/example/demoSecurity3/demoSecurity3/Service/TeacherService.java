package com.example.demoSecurity3.demoSecurity3.Service;

import com.example.demoSecurity3.demoSecurity3.Model.Book;
import com.example.demoSecurity3.demoSecurity3.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TeacherService {
    @Autowired
    BookRepository bookRepo;

    public ResponseEntity<?> allBooks() {

        List<Optional<Book>> books = new ArrayList<>();
        for(int i=5; i<=8;i++){
            books.add(bookRepo.findById(i));
        }
        return new ResponseEntity<>(books, HttpStatus.valueOf(200));
    }
}
