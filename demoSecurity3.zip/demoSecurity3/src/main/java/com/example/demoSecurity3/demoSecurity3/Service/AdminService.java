package com.example.demoSecurity3.demoSecurity3.Service;

import com.example.demoSecurity3.demoSecurity3.Model.Book;
import com.example.demoSecurity3.demoSecurity3.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
    @Autowired
    BookRepository bookRepo;

    public ResponseEntity<?> addBook(Book book) {
        bookRepo.save(book);
        return new ResponseEntity<>(book, HttpStatus.OK);
    }

    public ResponseEntity<?> allBooks() {

        return new ResponseEntity<>(bookRepo.findAll(), HttpStatus.OK);
    }
}
