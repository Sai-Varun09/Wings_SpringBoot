package com.example.demoSecurity3.demoSecurity3.Controller;

import com.example.demoSecurity3.demoSecurity3.Service.StudentService;
import com.example.demoSecurity3.demoSecurity3.Service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Teacher")
public class TeacherController {
    @Autowired
    TeacherService teacherService;

    @GetMapping("/allBooks")
    public ResponseEntity<?> allBooks(){
        return teacherService.allBooks();
    }
}
