INSERT INTO Book(id, title, author, description) VALUES (1, 'DSA', 'Asheesh', 'Hands-on DSA book');
INSERT INTO Book(id, title, author, description) VALUES (2, 'Spring Boot', 'Shireesh', 'Hands-on Spring Boot book');
INSERT INTO Book(id, title, author, description) VALUES (3, 'Spring Security', 'Parvathi', 'Hands-on Spring Security book');
INSERT INTO Book(id, title, author, description) VALUES (4, 'Web Scraping', 'Umakanth', 'Hands-on Web Scraping book');

INSERT INTO Book(id, title, author, description) VALUES (5, 'Web Scraping teaching', 'Umakanth teacher', 'Hands-on Web Scraping book');
INSERT INTO Book(id, title, author, description) VALUES (6, 'Spring Security teaching', 'Parvathi teacher', 'Hands-on Spring Security book');
INSERT INTO Book(id, title, author, description) VALUES (7, 'Spring Boot teaching', 'Shireesh teacher', 'Hands-on Spring Boot book');
INSERT INTO Book(id, title, author, description) VALUES (8, 'DSA teaching', 'Asheesh teacher', 'Hands-on DSA book');



Insert Into User_Info(id, username, password, role) Values(1, 'Asheesh', 'Test@123', 'Student');
Insert Into User_Info(id, username, password, role) Values(2, 'Shireesh', 'Test@123', 'Teacher');
Insert Into User_Info(id, username, password, role) Values(3, 'Parvathi', 'Test@123', 'Admin');



--{
--    "id": 9,
--    "title": "new book",
--    "author": "new author",
--    "description": "new description"
--}