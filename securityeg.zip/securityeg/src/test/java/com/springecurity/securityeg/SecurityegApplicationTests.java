package com.springecurity.securityeg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityegApplicationTests {

	@Test
	void contextLoads() {
	}

}
