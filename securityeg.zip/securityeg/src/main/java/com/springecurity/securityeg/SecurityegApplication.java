package com.springecurity.securityeg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityegApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityegApplication.class, args);
		System.out.println("Hello World");
	}

}
