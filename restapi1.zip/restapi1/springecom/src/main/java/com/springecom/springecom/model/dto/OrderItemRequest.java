package com.springecom.springecom.model.dto;

public record OrderItemRequest(
    int productId,
    int quantity

) {}
