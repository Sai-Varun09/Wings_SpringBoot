package com.springecom.springecom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringecomApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringecomApplication.class, args);
		System.out.println("Hello World");
	}

}
