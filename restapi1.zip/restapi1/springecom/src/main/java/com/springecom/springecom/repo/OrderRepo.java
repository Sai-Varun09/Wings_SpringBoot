package com.springecom.springecom.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springecom.springecom.model.Order;

public interface OrderRepo extends JpaRepository<Order, Integer> {

    Optional<Order> findByOrderId(String orderId);
}
