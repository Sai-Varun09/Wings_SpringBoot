package com.springecom.springecom.model.dto;

import java.math.BigDecimal;

public record OrderItemRespose(
    String ProductName,
    int quantity,
    BigDecimal totalPrice
) {}
