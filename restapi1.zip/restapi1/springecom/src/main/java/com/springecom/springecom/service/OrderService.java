package com.springecom.springecom.service;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.springecom.springecom.model.Order;
import com.springecom.springecom.model.dto.OrderRequest;
import com.springecom.springecom.model.dto.OrderResponse;


@Service
public class OrderService {

    public OrderResponse placeOrder(OrderRequest orderRequest) {
        Order order = new Order();
        String OrderId = "ORD" + UUID.randomUUID().toString().substring(0,8).toUpperCase();
        order.setOrderId(OrderId);
        order.setCustomerName(orderRequest.customerName());
        order.setEmail(orderRequest.email());
        order.setStatus("PLACED");
        order.setOrderDate(LocalDate.now());

        return null;
    }

    public List<OrderResponse> getAllResponses() {
        return null;
    }

}
