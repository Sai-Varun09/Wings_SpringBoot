package com.springrest.restapi1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Restapi1Application {

	public static void main(String[] args) {
		SpringApplication.run(Restapi1Application.class, args);
		System.out.println("Hello World");
	}

}
